import { Component, OnInit } from '@angular/core';
import { ExpenseService } from '../service/expense.service';
import { Router } from '@angular/router';
import { Expense } from '../model/expense';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-add-expense',
  templateUrl: './add-expense.component.html',
  styleUrls: ['./add-expense.component.css']
})
export class AddExpenseComponent implements OnInit {

  exp: any = { expenseCode: 0, expenseType: '', expenseDescription: '' };
  expenses:Expense[];
  constructor(private ExpenseService: ExpenseService, private router: Router, private http: HttpClient) { }

  ngOnInit() {
  }
  add() {

    this.ExpenseService.addExpense(this.exp).subscribe((data: Expense) => {
      this.exp = data;
      alert("Expense code details added successfully!");
      this.router.navigate(['displayall']);
    });


    }


  }
