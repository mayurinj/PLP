import { Component, OnInit, ChangeDetectorRef, Input } from '@angular/core';
import { Expense } from '../model/expense';
import { ExpenseService } from '../service/expense.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { ChangeDetectionStrategy } from '@angular/compiler/src/core';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  flag: boolean = false;
  expenses: Expense[] = [];
  searchedExpense: Expense;
  searchFound: boolean =  false;
  constructor(private expenseService: ExpenseService, private router: Router, private http: HttpClient) {
  }
  ngOnInit() {
  }

  filterData(value: number) {
    this.expenseService.searchExpense(value).subscribe((data: Expense) => {
      this.searchedExpense = data;
      if (this.searchedExpense != null) {
        this.searchFound = true;
      } else {
        this.searchFound = false;
        alert('Data not found');
      }
    });

  }

}
