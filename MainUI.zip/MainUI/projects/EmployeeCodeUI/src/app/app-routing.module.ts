import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DisplayEmployeeComponent } from './component/display-employee/display-employee.component';
import { AddEmployeeComponent } from './component/add-employee/add-employee.component';
import { DeleteEmployeeComponent } from './component/delete-employee/delete-employee.component';
import { ModifyEmployeeComponent } from './component/modify-employee/modify-employee.component';
import { SearchEmployeeComponent } from './component/search-employee/search-employee.component';
import { UpdateSearchComponent } from './component/update-search/update-search.component';
import { AppComponent } from 'projects/EmployeeCodeUI/src/app/app.component';


const routes: Routes = [
 // {path:'EmployeeCode',redirectTo:'EmployeeCode/list',pathMatch:'full'},
  {path:'list',component:DisplayEmployeeComponent},
  {path:'add', component:AddEmployeeComponent},
  {path:'search',component:SearchEmployeeComponent},
  {path:'delete',component:DeleteEmployeeComponent},
  {path:'update',component:ModifyEmployeeComponent},
  {path:'update-search',component:UpdateSearchComponent},
  {path:'EmployeeCode',pathMatch:'full',component:AppComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
