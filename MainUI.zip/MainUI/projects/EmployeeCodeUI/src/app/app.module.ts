import { BrowserModule } from '@angular/platform-browser';
import { NgModule, ModuleWithProviders } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DisplayEmployeeComponent } from './component/display-employee/display-employee.component';
import { AddEmployeeComponent } from './component/add-employee/add-employee.component';
import { ModifyEmployeeComponent } from './component/modify-employee/modify-employee.component';
import { DeleteEmployeeComponent } from './component/delete-employee/delete-employee.component';
import { SearchEmployeeComponent } from './component/search-employee/search-employee.component';
import { UpdateSearchComponent } from './component/update-search/update-search.component';
import {NgxPaginationModule} from 'ngx-pagination';
import {FormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    DisplayEmployeeComponent,
    AddEmployeeComponent,
    ModifyEmployeeComponent,
    DeleteEmployeeComponent,
    SearchEmployeeComponent,
    UpdateSearchComponent
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,FormsModule,HttpClientModule,NgxPaginationModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

@NgModule({})
export class EmployeeCodeModule{
  static forRoot(): ModuleWithProviders {
    return {
      ngModule: AppModule,
      providers: []
    }
  }
}