import { Component, OnInit } from '@angular/core';
import { Employeecode } from '../../model/employee-code';
import { EmployeeService } from '../../service/employee.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-delete-employee',
  templateUrl: './delete-employee.component.html',
  styleUrls: ['./delete-employee.component.css']
})
export class DeleteEmployeeComponent implements OnInit {

  del:String;
  submitted:boolean;
  flag:boolean=false;
  employee: Employeecode;
  delEmp:Employeecode;
  constructor(private empService:EmployeeService,private route:Router) { }
  ngOnInit() {
  }

  filterData(id: number)
  {
    this.flag=false;
     this.empService.searchEmployee(id).subscribe((data)=>{this.employee=data 
    
      if(this.employee)
      {        
       
        this.flag=true;
      }
      else
      {
        this.flag=false;
      }
    },error=>{alert('ID not found')});
      
      
    
  }

  deleteEmployee(id: number){
    //this.submitted=true;
    if(confirm('Are you sure you want to delete'))
    {
      this.empService.deleteEmployee(id).subscribe((data) =>{this.submitted=data
        if(this.submitted)
        {
          alert('Deleted successfully');
          this.route.navigate(['list']);
        }

      
    },error=>{alert('ID not found')} );
    }
    }

}
