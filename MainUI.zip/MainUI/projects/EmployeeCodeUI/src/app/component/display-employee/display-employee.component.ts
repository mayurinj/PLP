import { Component, OnInit } from '@angular/core';
import { Employeecode } from '../../model/employee-code';
import { EmployeeService } from '../../service/employee.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-display-employee',
  templateUrl: './display-employee.component.html',
  styleUrls: ['./display-employee.component.css']
})
export class DisplayEmployeeComponent implements OnInit {

  p:number=1;
  flag: boolean = false;
  employees:Employeecode[];
  constructor(private employeeService:EmployeeService,private router:Router, private http: HttpClient) { }

  ngOnInit() {
    //this.employees=this.employeeService.getAllEmployees();
    this.http.get<Employeecode[]>('http://localhost:8081/employeecode/display/').subscribe((data:Employeecode[])=>{
      this.employees=data;
      console.log("Datas are "+this.employees);
      if(this.employees.length>0)
        this.flag = true;
       else
        this.flag = false; 
    },error=>{alert('problem with service/url try again')});
  }
}
