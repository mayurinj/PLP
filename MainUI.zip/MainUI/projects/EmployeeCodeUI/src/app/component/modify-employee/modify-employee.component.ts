import { Component, OnInit } from '@angular/core';
import { Employeecode } from '../../model/employee-code';
import { EmployeeService } from '../../service/employee.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-modify-employee',
  templateUrl: './modify-employee.component.html',
  styleUrls: ['./modify-employee.component.css']
})
export class ModifyEmployeeComponent implements OnInit {

  emp: Employeecode = {
    empId: 0, empName: '', empPAN: '', empDesg: '', empDomain: '',
    empDOJ: null, empDOB: null, empSal: 0., empMail: '', empPassword: ''
  };
  constructor(private empService: EmployeeService, private route: Router) {
    this.emp = this.empService.fetchInitialEmployeeDetails();
   }
  ngOnInit() {
    this.emp = this.empService.fetchInitialEmployeeDetails();
  }
  updateEmployee() {
    this.empService.update(this.emp).subscribe(
      success => alert('Update Successful'),
      error => alert(error)
    );
    this.route.navigate(['list']);
  }
  compare() {
    if (this.emp.empDOB > this.emp.empDOJ) {
      alert('Dates are not in proper order');
      this.emp.empDOB = null;
      this.emp.empDOJ = null;
    }
  }
}
