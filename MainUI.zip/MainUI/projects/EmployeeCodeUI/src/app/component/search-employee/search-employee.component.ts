import { Component, OnInit } from '@angular/core';
import { Employeecode } from '../../model/employee-code';
import { EmployeeService } from '../../service/employee.service';

@Component({
  selector: 'app-search-employee',
  templateUrl: './search-employee.component.html',
  styleUrls: ['./search-employee.component.css']
})
export class SearchEmployeeComponent implements OnInit {

  employee: Employeecode
  flag:boolean=false;
  constructor(private empService: EmployeeService) { }

  ngOnInit() 
  {

  }

  filterData(id: number)
  {
    this.flag=false;
     this.empService.searchEmployee(id).subscribe((data)=>{this.employee=data 
    
      if(this.employee)
      {        
       
        this.flag=true;
      }
      else
      {
        this.flag=false;
      }
    },error=>{alert('ID not found')});
      
      
    
  }

}
