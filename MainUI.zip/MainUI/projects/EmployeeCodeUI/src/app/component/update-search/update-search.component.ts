import { Component, OnInit } from '@angular/core';
import { Employeecode } from '../../model/employee-code';
import { EmployeeService } from '../../service/employee.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-update-search',
  templateUrl: './update-search.component.html',
  styleUrls: ['./update-search.component.css']
})
export class UpdateSearchComponent implements OnInit {
  emp: number;
  result: Employeecode;
  constructor(private empService: EmployeeService, private route: Router) { }
  ngOnInit() {
  }
  sendSearchRequest(): void {
    this.empService.searchEmployee(this.emp).subscribe((data: Employeecode) => {
      this.result = data;
      //console.log(this.result);
      this.empService.setEmpDetail(this.result);
      this.route.navigate(['update']);
    }, error => { alert('No Records Found for the given Employee Id'); });
  }

}
