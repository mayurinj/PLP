import { EmployeeCode } from './employee-code';

describe('EmployeeCode', () => {
  it('should create an instance', () => {
    expect(new EmployeeCode()).toBeTruthy();
  });
});
