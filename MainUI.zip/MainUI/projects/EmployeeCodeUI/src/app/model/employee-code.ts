export class Employeecode 
{
    empId:number;
    empName:string;
    empPAN:string;
    empDesg:string;
    empDomain:string;
    empDOJ:Date;
    empDOB:Date;
    empSal:number;
    empMail:string;
    empPassword:string;

}
