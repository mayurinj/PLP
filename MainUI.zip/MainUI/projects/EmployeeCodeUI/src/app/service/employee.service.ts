import { Injectable } from '@angular/core';
import { Employeecode } from '../model/employee-code';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable,throwError } from 'rxjs';
import {retry,catchError} from 'rxjs/operators'
@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  displayUrl:string='http://localhost:8081/employeecode/display/';
  searchUrl:string='http://localhost:8081/employeecode/find/';
  addUrl:string='http://localhost:8081/employeecode/addEmployee/';
  modifyUrl:string='http://localhost:8081/employeecode/modify/';
  deleteUrl:string='http://localhost:8081/employeecode/delete/';
  Employees:Employeecode[];
  empcode: Employeecode;
  filterData:Employeecode;
  updateEmployee:Employeecode;
  constructor(private http:HttpClient, private router:Router)
   { 
     this.getEmployees();
   }

  getData():Observable<Employeecode[]>{
    return this.http.get<Employeecode[]>(this.displayUrl).pipe(
      retry(2),catchError(this.handleError)
    );
  }
    handleError(error){
      console.log(error);
      return throwError(error);
    }
  


  getEmployees(){
    this.getData().subscribe((data:Employeecode[])=>{
      this.Employees=data;
      console.log("Datas are "+this.Employees);

    },error=>{alert('problem with service/url try again')});
  }
  getAllEmployees(){
    return this.Employees;

  }
  
  searchEmployee(id: number)
  {
    return this.http.get<Employeecode>(this.searchUrl + id);
   
  }

  

  createEmployee(employee: Employeecode):Employeecode
   {
     this.http.post(this.addUrl,employee).subscribe((data: Employeecode)=>{
      this.empcode = data,
     success => alert("Done"),
     error => alert(error)
     this.router.navigate(['list']);
   });
   return this.empcode;
    }

    fetchInitialEmployeeDetails() {
      return this.updateEmployee;
    }
    setEmpDetail(employee: Employeecode) {
      
      this.updateEmployee = employee;
    }
    update(emp: Employeecode): Observable<any> {
      return this.http.put<Employeecode>(this.modifyUrl, emp);
    }

    deleteEmployee(id: number): Observable<any>
  {
    return this.http.delete<boolean>(this.deleteUrl+id);
  }

}
