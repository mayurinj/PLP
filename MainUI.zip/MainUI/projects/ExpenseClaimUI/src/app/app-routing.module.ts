import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppComponent } from 'projects/ExpenseClaimUI/src/app/app.component';
import { ClaimComponent } from './component/claim/claim.component';
import { ProjectComponent } from './component/project/project.component';
import { ExpenseComponent } from './component/expense/expense.component';
import { AddclaimComponent } from './component/addclaim/addclaim.component';
import { UpdateComponent } from './component/update/update.component';
import { ViewComponent } from './component/view/view.component';
import { DeleteComponent } from './component/delete/delete.component';
import { ViewAllComponent } from './component/view-all/view-all.component';



const routes: Routes = [

  {path:'ExpenseClaim',pathMatch:'full',component:AppComponent},
  { path: 'ExpenseClaim/add', component:ClaimComponent },
  { path: 'ExpenseClaim/project', component:ProjectComponent },
  { path: 'ExpenseClaim/Expense', component:ExpenseComponent },
  { path: 'ExpenseClaim/Claim', component:AddclaimComponent },
  { path: 'ExpenseClaim/update', component: UpdateComponent},
  { path : 'ExpenseClaim/view' , component : ViewComponent },
  { path : 'ExpenseClaim/delete' , component : DeleteComponent },
  { path : 'ExpenseClaim/viewall' , component : ViewAllComponent }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
