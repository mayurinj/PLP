import { BrowserModule } from '@angular/platform-browser';
import { NgModule, ModuleWithProviders } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddclaimComponent } from './component/addclaim/addclaim.component';
import { ClaimComponent } from './component/claim/claim.component';
import { DeleteComponent } from './component/delete/delete.component';
import { ExpenseComponent } from './component/expense/expense.component';
import { ProjectComponent } from './component/project/project.component';
import { UpdateComponent } from './component/update/update.component';
import { ViewComponent } from './component/view/view.component';
import { ViewAllComponent } from './component/view-all/view-all.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import {NgxPaginationModule} from 'ngx-pagination';

@NgModule({
  declarations: [
    AppComponent,
    AddclaimComponent,
    ClaimComponent,
    DeleteComponent,
    ExpenseComponent,
    ProjectComponent,
    UpdateComponent,
    ViewComponent,
    ViewAllComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,FormsModule,HttpClientModule,ReactiveFormsModule,NgxPaginationModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }


@NgModule({})
export class ExpenseClaimModule{
  static forRoot(): ModuleWithProviders {
    return {
      ngModule: AppModule,
      providers: []
    }
  }
}
