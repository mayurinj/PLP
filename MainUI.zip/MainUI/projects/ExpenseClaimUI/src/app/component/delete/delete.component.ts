import { Component, OnInit } from '@angular/core';
import { ClaimService } from '../../service/claim.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-delete',
  templateUrl: './delete.component.html',
  styleUrls: ['./delete.component.css']
})
export class DeleteComponent implements OnInit {

  del: string ;
  submitted = false;
  constructor(private expService: ClaimService,private router:Router) { }

  ngOnInit() {
  }

  deleteExpense(id: number) {
    this.submitted = true;
    this.expService.deleteExpence(id).subscribe(del => {
      if(del!=null){
        alert('Successful Deletion');
      }else{
        alert("Invalid ID");
      }
      this.router.navigate(['ExpenseClaim/viewall']);
    });
  }

}
