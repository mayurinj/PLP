import { Component, OnInit } from '@angular/core';

import { Router } from '@angular/router';
import { Project } from '../../model/project';
import { Observable } from 'rxjs';
import { ClaimService } from '../../service/claim.service';

@Component({
  selector: 'app-project',
  templateUrl: './project.component.html',
  styleUrls: ['./project.component.css']
})
export class ProjectComponent implements OnInit {

  project: Project = { id: 0, name: '', description: '', startDate: null, endDate: null, businessUnit: '' };
  projects: Project[];
  flag: boolean = false;
  flag1: boolean = false;
  projectNum = 0;
  public pro$ = new Observable<Project[]>();
  constructor(private service: ClaimService, private router: Router) { }

  ngOnInit() {
    this.flag = false;
    this.pro$ = this.service.getProject();
    this.pro$.subscribe((data: Project[]) => {
      this.projects = data;
      // if (this.project.id == 0) {
      //   this.flag = false;
      // }
      // else {
      //   this.flag = true;
      // }
      

    }, error => { alert('No Data by this Id') });
  }

  check(){
    
    if (this.project.id == 0) {
      this.flag = false;
    }
    else {
      this.flag = true;
    }
  }
  searchExpense() {
    this.service.project = this.project;
    this.router.navigate(['ExpenseClaim/Expense']);
  }
}
