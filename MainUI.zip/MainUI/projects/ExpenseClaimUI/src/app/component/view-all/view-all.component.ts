import { Component, OnInit } from '@angular/core';
import { ExpenseClaimed } from '../../model/expense-claimed';
import { ClaimService } from '../../service/claim.service';

@Component({
  selector: 'app-view-all',
  templateUrl: './view-all.component.html',
  styleUrls: ['./view-all.component.css']
})
export class ViewAllComponent implements OnInit {

  p:number=1;
  flag: boolean = false;
  claims: ExpenseClaimed[];

  constructor(private service: ClaimService) { }

  ngOnInit() {
    this.service.getClaims().subscribe((data)=> {this.claims=data;
    if(this.claims.length>0)
      this.flag = true;
    else
      this.flag = false;
  }
    );
  }


}
