import { ExpenseClaimed } from './expense-claimed';

describe('ExpenseClaimed', () => {
  it('should create an instance', () => {
    expect(new ExpenseClaimed()).toBeTruthy();
  });
});
