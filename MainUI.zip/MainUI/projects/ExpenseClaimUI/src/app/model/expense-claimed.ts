export class ExpenseClaimed
 {
    expenseCodeId: number;
    employeeId: number;
    projectCode: number;
    expenseCode: number;
    startDate: Date;
    endDate: Date;
    expenseAmount: number;
}
