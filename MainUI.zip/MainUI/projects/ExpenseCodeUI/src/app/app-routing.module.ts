import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppComponent } from 'projects/ExpenseCodeUI/src/app/app.component';
import { DisplayallComponent } from './component/displayall/displayall.component';
import { AddExpenseComponent } from './component/add-expense/add-expense.component';
import { UpdateExpenseComponent } from './component/update-expense/update-expense.component';
import { SearchComponent } from './component/search/search.component';
import { DeleteComponent } from './component/delete/delete.component';


const routes: Routes = [
  {path:'ExpenseCode',pathMatch:'full',component:AppComponent},
  { path: 'ExpenseCode/displayall', component: DisplayallComponent},
  { path: 'ExpenseCode/add', component: AddExpenseComponent},
  { path: 'ExpenseCode/update', component: UpdateExpenseComponent},
  { path: 'ExpenseCode/search', component: SearchComponent},
  { path: 'ExpenseCode/delete', component: DeleteComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
