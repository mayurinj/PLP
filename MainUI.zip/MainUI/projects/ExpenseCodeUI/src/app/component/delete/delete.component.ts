import { Component, OnInit } from '@angular/core';
import { Expense } from '../../model/expense';
import { ExpenseService } from '../../service/expense.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-delete',
  templateUrl: './delete.component.html',
  styleUrls: ['./delete.component.css']
})
export class DeleteComponent implements OnInit {

  searchedExpense: Expense;
  searchFound: boolean =  false;

  constructor(private expenseService: ExpenseService, private router: Router, private http: HttpClient) { }

  ngOnInit() {
  }
  filterData(value: number) {
    this.expenseService.searchExpense(value).subscribe((data: Expense) => {
      this.searchedExpense = data;
      if (this.searchedExpense != null) {
        this.searchFound = true;
      } else {
        this.searchFound = false;
        alert('Data not found');
      }
    });

  }
  deleteData(value: number) {
    this.expenseService.deleteExpense(value).subscribe((data: Expense) => {
      this.searchedExpense = data;
      if (this.searchedExpense != null) {
        this.searchFound = false;
        alert('Data deleted successfully!');
      } else {
        this.searchFound = false;
        alert('Data not found!');
      }

    });
  
  }
}
