import { Component, OnInit } from '@angular/core';
import { Expense } from '../../model/expense';
import { ExpenseService } from '../../service/expense.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-displayall',
  templateUrl: './displayall.component.html',
  styleUrls: ['./displayall.component.css']
})
export class DisplayallComponent implements OnInit {

  flag: boolean = false;
  expenses: Expense[] = [];
  constructor(private expenseService: ExpenseService, private router: Router, private http: HttpClient) {
    this.http.get<Expense[]>('http://localhost:8083/ExpenseCode/displayall/').subscribe((data: Expense[]) => {
      this.expenses = data;
    });
    this.expenses = this.expenseService.getExpenses();

  }

  ngOnInit() {
    this.http.get<Expense[]>('http://localhost:8083/ExpenseCode/displayall/').subscribe((data: Expense[]) => {
      this.expenses = data;
      if (this.expenses != null) {
        this.flag = true;
      }
      else {
        this.flag = false;
      }
    });
  }

  delete(i) {
    this.expenseService.deleteExpense(i).subscribe(
      data => {
        this.http.get<Expense[]>('http://localhost:8083/ExpenseCode/displayall/').subscribe(data => {
          this.expenses = data;
          if (this.expenses != null) {
            this.flag = true;
          }
          else {
            this.flag = false;
          }
          // this.router.navigate(['displayall']);
        });
      },
      error => console.log(error));
  }

  update(i) {
    this.expenseService.setIndex(i);
    this.router.navigate(['ExpenseCode/update']);
  }

}
