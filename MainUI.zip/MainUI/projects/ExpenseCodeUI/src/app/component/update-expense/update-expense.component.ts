import { Component, OnInit } from '@angular/core';
import { Expense } from '../../model/expense';
import { ExpenseService } from '../../service/expense.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-update-expense',
  templateUrl: './update-expense.component.html',
  styleUrls: ['./update-expense.component.css']
})
export class UpdateExpenseComponent implements OnInit {

  index: number;
  exp: Expense = { expenseCode: 0, expenseType: '', expenseDescription: '' };
  expenses: Expense[];
  // tslint:disable-next-line: no-shadowed-variable
  constructor(private expenseService: ExpenseService, private router: Router, private http: HttpClient) {

  }

  ngOnInit() {
    this.http.get<Expense[]>('http://localhost:8083/ExpenseCode/displayall/').subscribe((data: Expense[]) => {
      this.expenses = data;
      this.index = this.expenseService.getIndex();
      this.exp = this.expenseService.getExpense(this.index);

    });
  }
  update() {
    this.exp = this.expenseService.updateExpense(this.exp);
    this.http.get<Expense[]>('http://localhost:8083/ExpenseCode/displayall/').subscribe((data: Expense[]) => {
      this.expenses = data;
      //this.expenses = this.expenseService.getExpenses();
      alert('Expense code details updated successfully!');
      this.router.navigate(['ExpenseCode/displayall']);
    });
  }

}
