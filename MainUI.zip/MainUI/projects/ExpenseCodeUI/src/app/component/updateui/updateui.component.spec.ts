import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateuiComponent } from './updateui.component';

describe('UpdateuiComponent', () => {
  let component: UpdateuiComponent;
  let fixture: ComponentFixture<UpdateuiComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdateuiComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateuiComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
