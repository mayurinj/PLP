import { Component, OnInit } from '@angular/core';
import { Expense } from '../../model/expense';
import { ExpenseService } from '../../service/expense.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-updateui',
  templateUrl: './updateui.component.html',
  styleUrls: ['./updateui.component.css']
})
export class UpdateuiComponent implements OnInit {

  flag: boolean = false;
  expenses: Expense[] = [];
  searchedExpense: Expense;
  searchFound: boolean =  false;
  constructor(private expenseService: ExpenseService, private router: Router, private http: HttpClient) {
  }
  ngOnInit() {
  }

  filterData(value: number) {
    this.expenseService.searchExpense(value).subscribe((data: Expense) => {
      this.searchedExpense = data;
      if (this.searchedExpense != null) {
        this.searchFound = true;
      } else {
        this.searchFound = false;
        alert('Data not found');
      }
    });

  }
   update(exp: Expense) {
     this.expenseService.setUpdateExp(exp);
     this.router.navigate(['ExpenseCode/update']);
  }
}
