export class Expense 
{

    expenseCode: number;
    expenseType: string;
    expenseDescription: string;
}
