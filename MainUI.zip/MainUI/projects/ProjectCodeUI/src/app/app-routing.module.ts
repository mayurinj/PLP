import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppComponent } from 'projects/ProjectCodeUI/src/app/app.component';
import { GetAllProjectsComponent } from './component/get-all-projects/get-all-projects.component';
import { AddProjectComponent } from './component/add-project/add-project.component';
import { SearchProjectComponent } from './component/search-project/search-project.component';
import { UpdateProjectComponent } from './component/update-project/update-project.component';


const routes: Routes = [

  {path:'ProjectCode',pathMatch:'full',component:AppComponent},
  { path: 'ProjectCode/Display', component: GetAllProjectsComponent },
  { path: 'ProjectCode/Add', component: AddProjectComponent },
  { path: 'ProjectCode/Search', component: SearchProjectComponent },
  { path: 'ProjectCode/Update', component: UpdateProjectComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
