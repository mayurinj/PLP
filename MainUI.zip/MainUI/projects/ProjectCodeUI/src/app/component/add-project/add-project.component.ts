import { Component, OnInit } from '@angular/core';
import { Project } from '../../model/project';
import { ProjectService } from '../../service/project.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-project',
  templateUrl: './add-project.component.html',
  styleUrls: ['./add-project.component.css']
})
export class AddProjectComponent implements OnInit {

  project: Project = new Project();
  submitted = false;
  invalidDate = false;
  constructor(private projectService: ProjectService,private router:Router) { }

  ngOnInit() {
    this.submitted = false;
    this.invalidDate = false;
  }
  newProject(): void {
    this.submitted = false;
    this.project = new Project();
  }
  save() {
    this.projectService.addProduct(this.project).subscribe(data => console.log(data), error => console.log(error));
    this.project = new Project();
  }

  onSubmit() {
    this.submitted = true;
    this.save();
    alert('Project added successfully')
    this.router.navigate(['ProjectCode/Display'])
  }
  compare()
  {
    if ( this.project.startDate > this.project.endDate) {
    alert( 'start date should be before end date');
    }
  }

}
