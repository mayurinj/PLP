import { Injectable } from '@angular/core';
import { Project } from '../model/project';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProjectService {

  baseUrl = 'http://localhost:8082/project';
  project: Project;
  id: number;
  constructor(private http: HttpClient) { }

  getUpdateData(project: Project): Project {
    this.id = project.id;
    this.project = project;
    return this.project;
  }

  addProduct(project: Project): Observable<Project> {
    return this.http.post<Project>(`${this.baseUrl}/`, project);
  }

  displayAllProject(): Observable<Project[]> {
    return this.http.get<Project[]>(`${this.baseUrl}/`);
  }

  deleteProject(id: number): Observable<Project> {
    //return this.http.delete<Project>(`${this.baseUrl}/${id}`, { responseType: 'text' });
    return this.http.delete<Project>(`${this.baseUrl}/${id}`)//.subscribe(data=>{console.log(data)}, err=>{console.log(err)});
  }

  updateProject() {
    //console.log(this.project);
    return this.http.put(`${this.baseUrl}/`, this.project);
  }

  searchProject(id: number) {
    return this.http.get(`${this.baseUrl}/${id}`);
  }
}
