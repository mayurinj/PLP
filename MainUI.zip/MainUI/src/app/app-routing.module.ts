import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EmployeeCodeModule } from 'projects/EmployeeCodeUI/src/app/app.module';
import { ExpenseClaimModule } from 'projects/ExpenseClaimUI/src/app/app.module';
import { ExpenseCodeModule } from 'projects/ExpenseCodeUI/src/app/app.module';
import { ProjectCodeModule } from 'projects/ProjectCodeUI/src/app/app.module';


const routes: Routes = [
  {path:'EmployeeCode',loadChildren:'projects/EmployeeCodeUI/src/app/app.module#EmployeeCodeModule'},
  {path:'ExpenseClaim',loadChildren:'projects/ExpenseClaimUI/src/app/app.module#ExpenseClaimModule'},
  {path:'ExpenseCode',loadChildren:'projects/ExpenseCodeUI/src/app/app.module#ExpenseCodeModule'},
  {path:'ProjectCode',loadChildren:'projects/ProjectCodeUI/src/app/app.module#ProjectCodeModule'},
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes),
    EmployeeCodeModule.forRoot(),
    ExpenseClaimModule.forRoot(),
    ExpenseCodeModule.forRoot(),
    ProjectCodeModule.forRoot()


  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
