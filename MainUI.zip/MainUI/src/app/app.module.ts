import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { EmployeeCodeModule } from 'projects/EmployeeCodeUI/src/app/app.module';
import { ExpenseClaimModule } from 'projects/ExpenseClaimUI/src/app/app.module';
import { ExpenseCodeModule } from 'projects/ExpenseCodeUI/src/app/app.module';
import { ProjectCodeModule } from 'projects/ProjectCodeUI/src/app/app.module';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    EmployeeCodeModule.forRoot(),
    ExpenseClaimModule.forRoot(),
    ExpenseCodeModule.forRoot(),
    ProjectCodeModule.forRoot()
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
